import os
import json
import time
import traceback

seats_file = os.environ.get("SEATS_FILE", "")
command_file = os.environ.get("COMMAND_FILE", "")


def log_msg(msg: str) -> None:
    base_dir = os.path.dirname(seats_file) if seats_file else os.getcwd()
    log_path = os.path.join(base_dir, "python_debug.log")
    try:
        with open(log_path, "a", encoding="utf-8") as lf:
            lf.write(f"[{time.strftime('%H:%M:%S')}] {msg}\n")
    except Exception:
        pass


def load_data() -> dict:
    if not seats_file or not os.path.exists(seats_file):
        return {}
    with open(seats_file, "r", encoding="utf-8") as f:
        return json.load(f)


def save_data(data: dict) -> None:
    tmp_file = f"{seats_file}.tmp"
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    os.replace(tmp_file, seats_file)


def main() -> None:
    log_msg(f"Started. SEATS_FILE={seats_file!r}, COMMAND_FILE={command_file!r}")

    while True:
        if command_file and os.path.exists(command_file):
            try:
                # Brief pause so Dart finishes flushing command.json before Python reads it
                time.sleep(0.02)
                with open(command_file, "r", encoding="utf-8") as f:
                    cmd = json.load(f)

                passenger_name = cmd.get("passenger_name", "").strip()
                seat_code = cmd.get("seat_code", "").strip()
                log_msg(f"Received command: seat={seat_code!r}, name={passenger_name!r}")

                if passenger_name and seat_code:
                    seats = load_data()
                    if seat_code in seats:
                        if seats[seat_code].get("is_booked", False):
                            log_msg(f"Seat {seat_code} already booked.")
                        else:
                            seats[seat_code]["passenger"] = passenger_name
                            seats[seat_code]["is_booked"] = True
                            save_data(seats)
                            log_msg(f"Saved booking for {seat_code} -> {passenger_name}")
                    else:
                        log_msg(f"Seat {seat_code} not found in seats.json")
            except Exception as e:
                log_msg(f"ERROR: {e}\n{traceback.format_exc()}")
            finally:
                try:
                    if os.path.exists(command_file):
                        os.remove(command_file)
                except Exception as rm_err:
                    log_msg(f"Failed to remove command.json: {rm_err}")

        time.sleep(0.1)


if __name__ == "__main__":
    main()