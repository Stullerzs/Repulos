import os
import json

seats_file = os.environ.get("SEATS_FILE", "./assets/seats.json")

def load_data():
    if not os.path.exists(seats_file):
        return {}
    with open(seats_file, "r", encoding="utf-8") as f:
        return json.load(f)

def del_data():
    open(seats_file, "w", encoding="utf-8").close()

def save_data(data):
    with open(seats_file, "a", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

seat = {}

columns = ["A", "B", "C", "D"]

def generator(nev):
    new_dic = {nev: {}}
    clas = "Business"
    if int(nev[:-1]) > 2:
        clas = "Economy"
    values = [{"class": clas}, {"is_booked": False}, {"passenger": "Nincs utas"}]
    for val in values:
        new_dic[nev].update(val)
    return new_dic

for i in columns:
    for c in range(19):
        add_dic = generator(str(c + 1) + i)
        seat.update(add_dic)

del_data()
save_data(seat)